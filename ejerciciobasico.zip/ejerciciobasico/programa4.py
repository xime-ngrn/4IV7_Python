n = int(input("Introduce un número menor a 10: "))

while n > 10:
    n = int(input("Introduce un número menor a 10: "))

print(f"el numero {n} es menor a 10")