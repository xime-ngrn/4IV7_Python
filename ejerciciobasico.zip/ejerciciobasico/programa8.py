print("Suma")
print("Introduce 0 para terminar")
n=1
acumulador=0

while n!=0:
    n = int(input("Introduce un número: "))
    acumulador+=n
    print(f"La suma es {acumulador}")
    continue
