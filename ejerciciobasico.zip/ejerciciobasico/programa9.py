print("Suma hasta 100")
print("")

suma=0
while suma<100:
    n=int(input("Introduce un número:"))
    suma+=n
    continue

print(f"El total de la suma final es {suma}")